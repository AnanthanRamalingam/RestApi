package com.auth.token;

import java.security.interfaces.RSAPublicKey;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.log4j.Logger;
import org.jose4j.jwk.RsaJsonWebKey;
import org.jose4j.jwk.RsaJwkGenerator;
import org.jose4j.jws.AlgorithmIdentifiers;
import org.jose4j.jws.JsonWebSignature;
import org.jose4j.jwt.JwtClaims;
import org.jose4j.jwt.consumer.JwtConsumer;
import org.jose4j.jwt.consumer.JwtConsumerBuilder;
import org.jose4j.keys.resolvers.JwksVerificationKeyResolver;

//import com.jwt.auth.JWTTokenCreate;



import sun.misc.BASE64Encoder;

/*
 * auth/token
 * http://localhost:portno/jwttokenauthentication/restapi/auth/token
 */

@Path("/auth")
public class UserAuthenticate {
	private static Logger logger = Logger.getLogger(UserAuthenticate.class);

	@Path("/token")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public String authenticateuser(Credentials credentials){
		String userName = null;
		String password = null;
		String ResponseToken = null;
		JwtClaims receivedClaims;
		try{

			// get the username and password from the user
			userName = credentials.getUsername();
			password = credentials.getPassword();
			// this part of code sender side like client
			//I have to user jwt josf4j.jar file
			//set the user name and genrated the token
			JwtClaims claims = new JwtClaims();
	        claims.setAudience(userName);
	        claims.setGeneratedJwtId();
	        logger.debug("Senders end :: " + claims.toJson());

	        
	      //SIGNING
	        logger.info(" SIGNING :: ");
	        RsaJsonWebKey jsonSignKey = RsaJwkGenerator.generateJwk(2048);
	        JsonWebSignature jws = new JsonWebSignature();
	        jws.setKey(jsonSignKey.getPrivateKey());
	        jws.setPayload(claims.toJson());
	        //user send to the sha256 algoritham.// 
	        jws.setAlgorithmHeaderValue(AlgorithmIdentifiers.RSA_USING_SHA256);
	        String signedJwt = jws.getCompactSerialization();
	        logger.debug("getting Signed algoritham key ::" + signedJwt); 
	        BASE64Encoder b64 = new BASE64Encoder();
	        RSAPublicKey rsaPub = (RSAPublicKey) jsonSignKey.getPublicKey();
	        logger.debug("getting base64encoder publickey ::" + rsaPub);
	        
	        
	        
	        /***************************RECEIVER'S END ***********************************/
	        //java object public key getting from sender side and binding that object to RsaJsonWebKey class
	        RsaJsonWebKey sign_jwk = new RsaJsonWebKey(rsaPub);
	        //mention algoritham
	        sign_jwk.setAlgorithm("RSA");
	        //the key shoule be set the sig or decryt , i have to taken singing
	        sign_jwk.setUse("sig");
	        //set the key id
	        sign_jwk.setKeyId("12345");
	        List jwks_list = new ArrayList();
	        jwks_list.add(sign_jwk);
	        
	        logger.debug("getting token id from server ::" + jwks_list);
	        //verification the key list 
	        JwksVerificationKeyResolver jwks_resolver = new JwksVerificationKeyResolver(jwks_list);
	        
	        
	        //after verification the key cosume and convert to json then send to client.
	        JwtConsumer consumer = new JwtConsumerBuilder()
	                                .setExpectedAudience(userName)
	                                .setVerificationKeyResolver(jwks_resolver)
	                                .build();
	        
	         receivedClaims = consumer.processToClaims(signedJwt);
	        ResponseToken = receivedClaims.toJson();
		}catch(Exception e){
			e.printStackTrace();
		}
		if("admin".equals(userName) && "password".equals(password)){
			logger.debug("SUCESS :: JWT Validation :: " + ResponseToken);
			return ResponseToken;
		}else {
			return "this is not correct user credentials";
		}
		
	}
	
}
